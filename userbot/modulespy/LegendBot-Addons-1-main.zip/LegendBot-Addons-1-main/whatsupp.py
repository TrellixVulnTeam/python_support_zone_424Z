from userbot.utils import admin_cmd
from userbot.cmdhelp import CmdHelp

@borg.on(admin_cmd(pattern="ftype ?(.*)"))
async def payf(event):
    paytext = event.pattern_match.group(1)
    pay = "{}\n{}\n{}\n{}\n{}\n{}\n{}\n{}\n{}\n{}\n{}\n{}".format(
        paytext * 8,
        paytext * 8,
        paytext * 2,
        paytext * 2,
        paytext * 2,
        paytext * 6,
        paytext * 6,
        paytext * 2,
        paytext * 2,
        paytext * 2,
        paytext * 2,
        paytext * 2,
    )
    await event.edit(pay)
CmdHelp("whatsupp").add_command(
    'ftype', 'Use and See','Eg:-.ftype legend'
).add()
