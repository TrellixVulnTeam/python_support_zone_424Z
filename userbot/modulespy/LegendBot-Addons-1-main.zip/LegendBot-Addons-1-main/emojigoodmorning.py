
import asyncio

from userbot.utils import admin_cmd
from userbot.cmdhelp import CmdHelp
CmdHelp("єg∂миg").add_command(
   'egm', None, 'Use in Gm Time'
).add()


@borg.on(admin_cmd(pattern="egm ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit(
            ".     😍😊😍😊😍😍\n 😊😍😍😍😍😊😍😊\n  😍😊                     😊😊\n 😍😍\n😍😊                😊😍😊😍\n😍😊                😍😊😊😊\n😍😊                        😊😍\n   😊😊                      😍😍\n     😍😊😍😍😍😊😊😍  \n          😊😊😊😍😍😊 "
        )
        await asyncio.sleep(2)
        await event.edit(
            ".           😍😊😊😊😍\n 😍😊😍😍😊😍😊\n   😍😊                   😊😍\n 😍😊                       😍😊\n😊😍                         😍😍\n😊😊                         😍😍\n 😊😊                       😍😍\n   😊😊                   😍😊\n      😍😍😍😍😍😍😊\n            😊😊😍😍😍"
        )
        await asyncio.sleep(2)
        await event.edit(
            ".           😊😊😍😊😊\n     😊😍😍😍😊😍😊\n   😊😍                   😍😊\n 😊😊                       😍😊\n😍😍                         😍😊\n😍😍                         😊😊\n 😍😊                       😍😍\n   😊😍                   😊😊\n      😊😊😍😍😊😊😊\n            😍😊😊😊😊"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😊😍😊😍😊😍😊\n😍😍😍😊😍😍😍😊\n😍😊                      😊😊\n😊😊                         😊😊\n😍😊                         😊😍\n😍😍                         😊😊\n😍😊                         😊😊\n😊😍                      😍😊\n😊😍😍😍😊😊😊😊\n😊😊😊😍😍😊😍\n\n"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😍😊                              😍😍\n😊😍😊                      😍😊😊\n😍😊😍😊            😊😊😊😍\n😊😊    😊😊    😊😊    😊😊\n😊😊        😊😊😊        😍😍\n😊😊             😍             😍😊\n😍😊                              😍😊\n😊😍                              😊😊\n😍😍                              😊😊\n😊😊                              😍😊"
        )
        await asyncio.sleep(2)
        await event.edit(
            ".           😍😊😊😊😍\n 😍😊😍😍😊😍😊\n   😍😊                   😊😍\n 😍😊                       😍😊\n😊😍                         😍😍\n😊😊                         😍😍\n 😊😊                       😍😍\n   😊😊                   😍😊\n      😍😍😍😍😍😍😊\n            😊😊😍😍😍"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😍😍😍😊😍😊😍\n😍😊😍😍😊😊😊😊\n😍😊                     😍😍\n😊😍                     😍😍\n😊😍😍😍😊😊😊😊\n😍😊😍😍😊😍😍\n😊😊    😍😊\n😍😍         😍😊\n😊😊              😊😊\n😊😊                  😍😊"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😊😍                           😍😍\n😍😍😊                       😊😍\n😊😊😍😍                 😍😊\n😍😍  😊😊               😍😊\n😍😊     😊😊            😊😊\n😊😍         😊😊        😍😊\n😊😍             😍😍    😍😍\n😊😍                 😊😍😊😊\n😍😊                     😊😍😊\n😍😊                          😊😍"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😊😊😊😍😊😍\n😊😍😊😍😍😍\n          😍😍\n          😍😍\n          😍😊\n          😍😊\n          😊😊\n          😊😊\n😍😊😍😊😊\n😊😍😍😊😊😊"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😊😍                           😍😍\n😍😍😊                       😊😍\n😊😊😍😍                 😍😊\n😍😍  😊😊               😍😊\n😍😊     😊😊            😊😊\n😊😍         😊😊        😍😊\n😊😍             😍😍    😍😍\n😊😍                 😊😍😊😊\n😍😊                     😊😍😊\n😍😊                          😊😍"
        )
        await asyncio.sleep(2)
        await event.edit(
            ".     😍😊😍😊😍😍\n 😊😍😍😍😍😊😍😊\n  😍😊                     😊😊\n 😍😍\n😍😊                😊😍😊😍\n😍😊                😍😊😊😊\n😍😊                        😊😍\n   😊😊                      😍😍\n     😍😊😍😍😍😊😊😍  \n          😊😊😊😍😍😊 "
        )
        await asyncio.sleep(2)
        await event.edit("GOOD MORNING ,HAVE A NICE DAY AHAED😊")
