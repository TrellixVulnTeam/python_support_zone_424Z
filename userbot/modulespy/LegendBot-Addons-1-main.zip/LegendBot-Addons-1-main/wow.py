
#Kang = ultra gey
#keep credits = cool coder😎
#usage :-.wow
#plz dont kang it take a lot of time to made😭
#, plz keep credits of Legend_mr_Hacker ⚡⚡

from telethon import events
import asyncio
from userbot.utils import admin_cmd
from userbot.cmdhelp import CmdHelp
from userbot import CMD_HELP
@borg.on(admin_cmd(pattern=r"wows"))
async def hapy(event):
     a="░█──░█ ░█▀▀▀█ ░█──░█ \n░█░█░█ ░█──░█ ░█░█░█ \n░█▄▀▄█ ░█▄▄▄█ ░█▄▀▄█"
     await event.edit(a)
CmdHelp("wows").add_command(
     'wows', None, 'Use and See'
).add()